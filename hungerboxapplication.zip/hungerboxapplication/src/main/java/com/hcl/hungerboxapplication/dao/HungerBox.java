package com.hcl.hungerboxapplication.dao;

public class HungerBox {

	public static final long HUNGERBOXNUMBER=8008775390l;
	
}
