package com.hcl.hungerboxapplication.exception;

public class ItemNotFoundException extends Exception{

	private static final long serialVersionUID = 1L;

public ItemNotFoundException(String s) {
	
}
}
