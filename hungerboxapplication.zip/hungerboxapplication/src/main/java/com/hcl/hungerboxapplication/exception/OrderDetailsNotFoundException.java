package com.hcl.hungerboxapplication.exception;

public class OrderDetailsNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

public OrderDetailsNotFoundException(String s) {
	
}
}
