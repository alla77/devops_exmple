package com.hcl.hungerboxapplication.exception;

public class PaymentNotSuccessfulException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public PaymentNotSuccessfulException(String s) {
		
	}
}
