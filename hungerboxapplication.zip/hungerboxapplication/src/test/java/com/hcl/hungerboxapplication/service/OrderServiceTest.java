package com.hcl.hungerboxapplication.service;

import java.util.Optional;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

import com.hcl.hungerboxapplication.dao.EmployeeRepository;
import com.hcl.hungerboxapplication.dao.ItemRepository;
import com.hcl.hungerboxapplication.dao.OrderItemRepository;
import com.hcl.hungerboxapplication.dao.OrderRepository;
import com.hcl.hungerboxapplication.dao.VendorRepository;
import com.hcl.hungerboxapplication.dto.OrderDto;
import com.hcl.hungerboxapplication.model.Employee;
import com.hcl.hungerboxapplication.model.Order;
import com.hcl.hungerboxapplication.model.Vendor;

@RunWith(MockitoJUnitRunner.Silent.class)
public class OrderServiceTest {
	
	@InjectMocks
	OrderServiceImpl orderService;
	
	@Autowired
	OrderItemRepository orderItemRepository;

	@Autowired
	EmployeeRepository employeeRepository;

	@Mock
	VendorRepository vendorRepository;

	@Mock
	OrderRepository orderRepository;

	@Mock
	ItemRepository itemRepository;

	@Mock
	RestTemplate restTemplate;
	static OrderDto orderDto=null;
	Employee employee=null;
	static Order order=null;
	static Vendor vendor=null;
	@Before
	public void setUp() {
	orderDto=new OrderDto();
	 employee=new Employee();
	Vendor vendor=new Vendor();
	order=new Order();
	employee.setEmail("bhavani@123");
	vendor.setVendorId(1L);
	employee.setEmployeeId(1L);
	
	order.setEmployee(employee);
	orderDto.setEmployeeId(1l);
	orderDto.setVendorId(1l);
	}
	
	
}
